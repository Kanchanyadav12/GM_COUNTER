/// \file SteppingAction.cc
/// \brief Implementation of the B1::SteppingAction class
#include "SteppingAction.hh"

#include "G4LogicalVolume.hh"
#include "G4RunManager.hh"
#include "G4Step.hh"
#include "G4SystemOfUnits.hh"

#include "DetectorConstruction.hh"
#include "EventAction.hh"
#include "RunAction.hh"

#include <algorithm>
#include <cmath>

namespace B1
{

SteppingAction::SteppingAction(RunAction* runAction) : fRunAction(runAction) {}

void SteppingAction::UserSteppingAction(const G4Step* step)
{
  if (!fScoringVolume)
  {
    const auto detConstruction = static_cast<const DetectorConstruction*>(
      G4RunManager::GetRunManager()->GetUserDetectorConstruction());

    fScoringVolume = detConstruction->GetScoringVolume();
  }

  auto volume = step->GetPreStepPoint()->GetTouchableHandle()
                  ->GetVolume()->GetLogicalVolume();

  G4String name = volume->GetName();
  G4cout << "Volume: " << name << G4endl;

  if (name == "Detector")
  {
      G4cout << "🔥 HIT DETECTOR 🔥" << G4endl;

      fRunAction->AddCount();

      step->GetTrack()->SetTrackStatus(fStopAndKill);
  }
}

}  // namespace B1