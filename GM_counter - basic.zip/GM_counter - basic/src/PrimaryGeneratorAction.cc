//  /// \file PrimaryGeneratorAction.cc
// /// \brief Implementation of the B1::PrimaryGeneratorAction class

#include "PrimaryGeneratorAction.hh"

#include "G4Event.hh"
#include "G4GeneralParticleSource.hh"
#include "G4SystemOfUnits.hh"
#include "G4ThreeVector.hh"
#include "G4ParticleGun.hh"
#include "G4Electron.hh"


namespace B1
{

PrimaryGeneratorAction::PrimaryGeneratorAction()
{
    fGPS = new G4GeneralParticleSource();

    // ✅ Use ELECTRON (beta particle)
    fGPS->SetParticleDefinition(G4Electron::Definition());

    // ================= POSITION =================
    fGPS->GetCurrentSource()->GetPosDist()->SetPosDisType("Point");
    fGPS->GetCurrentSource()->GetPosDist()->SetCentreCoords(
        G4ThreeVector(0., 0., 0.));

    // ================= DIRECTION =================
    fGPS->GetCurrentSource()->GetAngDist()->SetAngDistType("iso");
    fGPS->GetCurrentSource()->GetAngDist()->SetParticleMomentumDirection(
        G4ThreeVector(0., 0., 1.));

    // ================= ENERGY =================
    // Option 1: Monoenergetic (simplest)
    fGPS->GetCurrentSource()->GetEneDist()->SetEnergyDisType("Mono");
    fGPS->GetCurrentSource()->GetEneDist()->SetMonoEnergy(186 * keV);
    // ================= ENERGY (Co-60: 1.17 & 1.33 MeV) =================
    // auto eneDist = fGPS->GetCurrentSource()->GetEneDist();

    // eneDist->SetEnergyDisType("Arb");

    // // Define two energies
    // eneDist->ArbEnergyHistoFile("co60_spectrum.dat");

    // 🔥 (Advanced - optional later)
    // You can use spectrum instead of mono:
    // SetEnergyDisType("Arb") for realistic beta spectrum
}

PrimaryGeneratorAction::~PrimaryGeneratorAction()
{
    delete fGPS;
}

void PrimaryGeneratorAction::GeneratePrimaries(G4Event* event)
{
    fGPS->GeneratePrimaryVertex(event);
}

} // namespace B1




