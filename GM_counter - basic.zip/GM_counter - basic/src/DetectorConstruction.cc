/// \file DetectorConstruction.cc
/// \brief Implementation of the B1::DetectorConstruction class

#include "DetectorConstruction.hh"

#include "G4Box.hh"
#include "G4LogicalVolume.hh"
#include "G4NistManager.hh"
#include "G4PVPlacement.hh"
#include "G4SystemOfUnits.hh"
#include "G4Tubs.hh"
#include "G4Sphere.hh"

namespace B1
{

  G4VPhysicalVolume *DetectorConstruction::Construct()
  {
    G4NistManager *nist = G4NistManager::Instance();
    G4bool checkOverlaps = true;

    // ================= WORLD =================
    G4double world_size = 1.0 * m;
    G4Material *world_mat = nist->FindOrBuildMaterial("G4_AIR");

    auto solidWorld = new G4Box("World",
                               0.5 * world_size,
                               0.5 * world_size,
                               0.5 * world_size);

    auto logicWorld = new G4LogicalVolume(solidWorld,
                                          world_mat,
                                          "World");

    auto physWorld = new G4PVPlacement(nullptr,
                                       G4ThreeVector(),
                                       logicWorld,
                                       "World",
                                       nullptr,
                                       false,
                                       0,
                                       checkOverlaps);

    // ================= ALUMINIUM ABSORBER =================
    G4Material *Al = nist->FindOrBuildMaterial("G4_Al");

    // 🔁 CHANGE THIS VALUE FOR DIFFERENT RUNS
    G4double thickness = 0.40 * mm;

    auto solidAbsorber = new G4Box("Absorber",
                                  2 * cm,
                                  2 * cm,
                                  thickness / 2);

    auto logicAbsorber = new G4LogicalVolume(solidAbsorber,
                                            Al,
                                            "Absorber");

    new G4PVPlacement(nullptr,
                      G4ThreeVector(0, 0, 1 * cm), // placed after source
                      logicAbsorber,
                      "Absorber",
                      logicWorld,
                      false,
                      0,
                      checkOverlaps);

    // ================= GM DETECTOR =================
    G4Material *det_mat = nist->FindOrBuildMaterial("G4_AIR");

    auto solidDetector = new G4Box("Detector",
                                  5* cm,
                                  5* cm,
                                  2 * cm);

    auto logicDetector = new G4LogicalVolume(solidDetector,
                                            det_mat,
                                            "Detector");

    new G4PVPlacement(nullptr,
                      G4ThreeVector(0, 0, 5 * cm), // AFTER absorber
                      logicDetector,
                      "Detector",
                      logicWorld,
                      false,
                      0,
                      checkOverlaps);

    // 🎯 VERY IMPORTANT
    fScoringVolume = logicDetector;

    return physWorld;
  }
  
  
 
    

} // namespace B1
