#include "RunAction.hh"

#include "G4Run.hh"
#include "G4ios.hh"

#include <fstream>

namespace B1
{

RunAction::RunAction()
: G4UserRunAction(),
  fCount(0)
{}

// Called at beginning of run
void RunAction::BeginOfRunAction(const G4Run*)
{
  fCount = 0;  // reset count
}

// Called from SteppingAction
void RunAction::AddCount()
{
  fCount++;
}

// Called at end of run
void RunAction::EndOfRunAction(const G4Run*)
{
  if (!IsMaster()) return;

  G4cout << "Total Counts: " << fCount << G4endl;

  // Append counts to file
  std::ofstream out("counts.txt", std::ios::app);
  out << fCount << std::endl;
  out.close();

  G4cout << "Data written to counts.txt\n" << G4endl;
}

}  // namespace B1